L K SCHOOL IA — CONFIGURATION DES CONNEXIONS
Version du 9 novembre 2026

CE QUI A ÉTÉ AJOUTÉ AU SITE
- Formulaire de création de compte par e-mail et mot de passe.
- Formulaire de connexion et déconnexion.
- Choix de l'espace souhaité : élève, enseignant ou parent.
- Boutons Google et Apple (activation après configuration de chaque fournisseur).
- Profil utilisateur conservé dans Supabase.
- Protection : chaque nouvel inscrit reçoit le rôle élève par défaut. Les rôles
  enseignant et parent doivent être validés. Un visiteur ne peut pas devenir admin.
- Les deux comptes administrateurs (toi et ta grande sœur) doivent être promus
  explicitement dans Supabase après leur inscription.

IMPORTANT : LES COMPTES NE SONT PAS ENCORE ACTIVÉS
Ce ZIP contient l'intégration logicielle, mais une authentification réelle a besoin
d'un projet Supabase et de paramètres qui appartiennent au propriétaire du projet.
Sans ces paramètres, aucun site ne peut créer ni vérifier des comptes de façon sûre.
Il ne faut pas inventer ces identifiants.

ÉTAPE 1 — CRÉER LE PROJET SUPABASE
1. Ouvre https://supabase.com/ et crée un compte ou connecte-toi.
2. Crée un projet nommé par exemple lk-school-ia.
3. Garde le mot de passe de base de données privé.
4. Dans le tableau de bord, ouvre SQL Editor.
5. Ouvre le fichier supabase/schema.sql de ce ZIP, copie son contenu et exécute-le.

ÉTAPE 2 — CONFIGURER LE SITE
1. Dans Supabase, ouvre Project Settings > API (ou API Keys).
2. Copie l'URL du projet et la clé anon/publicable (publishable).
3. Dans le fichier supabase-config.js, remplace :
   https://VOTRE-PROJET.supabase.co par l'URL de ton projet ;
   VOTRE-CLE-ANON-PUBLIQUE par la clé publique anon/publishable.
4. Cette clé publique peut être dans le navigateur uniquement parce que les
   permissions sont protégées par les règles RLS du fichier SQL.
5. Ne mets JAMAIS la clé service_role, une clé secrète, un mot de passe ou la clé
   de base de données dans supabase-config.js, dans Cloudflare côté navigateur,
   ni dans une conversation.

ÉTAPE 3 — URLS DE REDIRECTION
Dans Supabase > Authentication > URL Configuration :
- Site URL : l'adresse publique exacte de ton site Cloudflare Pages.
- Redirect URLs : ajoute cette adresse et, si nécessaire, son adresse de prévisualisation.
Les URL doivent correspondre exactement au domaine réellement utilisé.

ÉTAPE 4 — GOOGLE ET APPLE
Les boutons sont présents, mais Google et Apple ne fonctionneront qu'après
activation de leurs fournisseurs dans Supabase > Authentication > Providers.
Chaque fournisseur demande ses propres identifiants OAuth et URL de rappel.
Pour Apple, un compte Apple Developer et sa configuration sont nécessaires.
Ne partage jamais les clés privées OAuth dans le code du site.

ÉTAPE 5 — COMPTES ADMINISTRATEURS
1. Inscris-toi d'abord avec ton adresse e-mail.
2. Inscris ta grande sœur avec son adresse e-mail.
3. Dans Supabase SQL Editor, exécute les deux commandes d'exemple à la fin de
   supabase/schema.sql en remplaçant les adresses par les vôtres.
Ne rends jamais le rôle admin disponible dans le formulaire public.

CE QUI EST INCLUS / CE QUI RESTE
Inclus dans le code : inscription, connexion, déconnexion, structure de profils,
demande d'accès enseignant/parent, boutons OAuth et règles de base de sécurité.
À configurer : projet Supabase, SQL, URL/clé publique, confirmation e-mail,
Google OAuth et Apple OAuth.
Pas encore inclus : relation parent-enfant et tableau de suivi, espace enseignant
complet, gestion fine des permissions administrateurs, synchronisation des notes,
quiz et paiements. Ces modules nécessitent des tables et règles supplémentaires.

DÉPLOIEMENT CLOUDFLARE
Après configuration de supabase-config.js, déploie le contenu du dossier extrait
dans le projet Pages existant. Le dossier functions/ doit rester à la racine pour
que le professeur IA continue à fonctionner. Conserve également le secret
OPENAI_API_KEY dans l'environnement Production de Cloudflare.
