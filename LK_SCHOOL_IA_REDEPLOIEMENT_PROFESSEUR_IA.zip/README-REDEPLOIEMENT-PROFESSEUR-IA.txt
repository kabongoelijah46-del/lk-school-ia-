L K SCHOOL IA — PAQUET DE REDÉPLOIEMENT DU PROFESSEUR IA
Version préparée le 10 novembre 2026

IMPORTANT : ce paquet contient le code du professeur IA, notamment
functions/api/ask.js. Cette fonction serveur doit être publiée pour que
les questions arrivent à OpenAI. La clé OpenAI n'est PAS incluse dans ce ZIP.

1) AVANT LE DÉPLOIEMENT
- Décompresse ce ZIP sur ton ordinateur.
- Vérifie que le dossier décompressé contient index.html, app.js, styles.css,
  _routes.json et surtout le dossier functions/api/ask.js.
- Dans Cloudflare > Workers & Pages > ton projet Pages > Settings > Variables
  and Secrets, ajoute/vérifie le secret OPENAI_API_KEY dans l'environnement
  Production. Colle ta clé OpenAI dans Cloudflare uniquement, jamais dans un
  fichier du site ni dans une conversation.
- Si le secret vient d'être ajouté/modifié, lance un nouveau déploiement.

2) MÉTHODE DE DÉPLOIEMENT À UTILISER POUR CE PAQUET
Le projet utilise une Cloudflare Pages Function dans le dossier functions/.
Le téléversement ZIP par glisser-déposer dans le tableau de bord Cloudflare
ne compile pas ce dossier Functions. Il faut publier avec Wrangler, ou avec
l'intégration Git déjà configurée pour le projet.

Méthode Wrangler (si le projet est en Direct Upload) :
- Installe Node.js sur l'ordinateur si nécessaire.
- Ouvre un terminal dans le dossier décompressé (celui qui contient index.html
  et functions/).
- Exécute : npx wrangler login
- Puis exécute, en remplaçant NOM_DU_PROJET par le nom exact du projet Pages
  visible dans Cloudflare :
  npx wrangler pages deploy . --project-name=NOM_DU_PROJET
- Confirme que le déploiement est Production.

Si Cloudflare indique que le projet est connecté à GitHub/GitLab, ne crée pas
un nouveau projet et ne change pas son mode de déploiement. Il faut alors
mettre ces fichiers dans le dépôt déjà relié et laisser Cloudflare construire
le déploiement, ou utiliser Wrangler selon la configuration existante.

3) TEST DU PROFESSEUR IA
Après le déploiement, ouvre le site publié et demande :
« Explique-moi les fractions avec un exemple simple. »
Le formulaire appelle /api/ask. Le serveur utilise OPENAI_API_KEY et le modèle
par défaut gpt-4.1-mini (modifiable par la variable OPENAI_MODEL).

4) DIAGNOSTIC RAPIDE
- « OPENAI_API_KEY absent » : le secret n'est pas défini dans Production, son
  nom est incorrect, ou le nouveau déploiement n'a pas été effectué.
- Erreur 401 : clé refusée par OpenAI ; vérifier la clé et son statut.
- Erreur 429 : vérifier crédits, facturation et limites API OpenAI.
- Erreur 502 : consulter le message d'erreur et les journaux de la fonction.

SÉCURITÉ
Ne partage jamais ta clé API. Ne l'inscris pas dans app.js, index.html,
 supabase-config.js, ni dans un fichier ZIP. Seul le secret Cloudflare doit
la contenir. L'utilisation de l'API OpenAI peut entraîner des frais.

CONTENU DU PROJET
Le site, le formulaire du professeur IA, la fonction serveur /api/ask,
la configuration Supabase (à compléter séparément) et le schéma SQL sont inclus.
Les comptes Supabase, les paiements, les quiz complets, le bloc-notes et les
autres modules annoncés restent à configurer ou développer.
