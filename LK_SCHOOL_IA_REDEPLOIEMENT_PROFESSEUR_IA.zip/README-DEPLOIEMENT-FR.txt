L K SCHOOL IA — PAQUET DE DÉPLOIEMENT CLOUDFLARE PAGES
Version corrigée du 9 novembre 2026

CONTENU
- index.html : page d'accueil et présentation des espaces et fonctionnalités.
- styles.css : design responsive noir et or.
- app.js : authentification Supabase (inscription, connexion, déconnexion, OAuth) et formulaire du professeur IA.
- functions/api/ask.js : fonction serveur Cloudflare Pages qui appelle réellement l'API OpenAI.
- _routes.json : routage de la fonction API.
- supabase-config.js : URL et clé publique Supabase à renseigner.
- supabase/schema.sql : tables, profils, déclencheur et règles de sécurité.
- README-CONNEXIONS-FR.txt : guide de configuration des comptes.

IMPORTANT AVANT DE DÉPLOYER
Ce ZIP est organisé avec les fichiers directement à sa racine. Après extraction,
le dossier à téléverser est le dossier qui contient directement index.html,
styles.css, app.js, _routes.json et le dossier functions.

DÉPLOIEMENT
1. Dans Cloudflare, ouvre le projet Pages existant de L K SCHOOL IA.
2. Ce projet contient functions/api/ask.js. Pour conserver cette fonction,
   utilise Wrangler (voir README-REDEPLOIEMENT-PROFESSEUR-IA.txt) ou le dépôt Git
   déjà relié. Le glisser-déposer ZIP du tableau de bord ne compile pas le dossier
   functions/.
3. Ne crée pas un deuxième projet et ne supprime pas l'ancien déploiement.
4. Dans Settings > Variables and Secrets, vérifie que OPENAI_API_KEY est de type
   Secret et qu'il contient la clé API. Ne mets jamais la clé dans un fichier.
5. Facultatif : ajoute OPENAI_MODEL comme variable texte avec gpt-4.1-mini.
6. Déploie en Production.
7. Sur le site publié, pose une question simple dans le bloc Professeur IA.

DIAGNOSTIC
- Message indiquant que OPENAI_API_KEY est absent : vérifier le nom exact du secret
  et l'environnement Production (pas seulement Preview), puis redéployer.
- Erreur 401 : clé refusée par OpenAI; vérifier la clé et son statut.
- Erreur 429 : vérifier crédits, facturation et limites API OpenAI.
- Erreur 502 : consulter le message affiché et les journaux de la fonction Cloudflare.

CE QUI FONCTIONNE DANS CETTE VERSION
- La page d'accueil responsive.
- Le formulaire qui envoie une question à /api/ask.
- La fonction serveur qui transmet la question à OpenAI sans exposer la clé au navigateur.
- La gestion des principales erreurs de connexion.

CE QUI EST PRÉSENTÉ MAIS PAS ENCORE OPÉRATIONNEL
Les formulaires d'inscription/connexion et la structure de profils sont maintenant
intégrés avec Supabase, mais ils ne seront réellement actifs qu'après création du
projet Supabase et configuration décrite dans README-CONNEXIONS-FR.txt.
Le suivi parent-enfant, bloc-notes synchronisé, quiz avec compteur fiable, espace
enseignant complet, groupes, mini-jeux, export Word/Excel et paiements Mobile Money
restent à développer.

TARIFS AFFICHÉS SELON LES DERNIÈRES INSTRUCTIONS
- Gratuit : 0 $
- Premium : 50 $ par mois ou 500 $ par an.

NOTE SUR LE MOTEUR DE RECHERCHE
Cette version connecte le professeur IA à l'API OpenAI pour répondre aux questions.
Elle ne réalise pas encore une recherche Internet avec citations de sources.
Une vraie recherche web nécessite une intégration supplémentaire et des règles
de sécurité/quotas adaptées.

SÉCURITÉ ET COÛTS
La clé API reste côté serveur dans le secret Cloudflare. L'utilisation de l'API
OpenAI peut entraîner des frais séparés. Configure des limites de dépenses
dans ton compte OpenAI et ne partage jamais ta clé.
