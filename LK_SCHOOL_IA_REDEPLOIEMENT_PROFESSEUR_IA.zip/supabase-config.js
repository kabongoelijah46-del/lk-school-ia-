// Configuration publique Supabase pour L K SCHOOL IA.
// Remplace ces deux valeurs par celles de ton projet Supabase.
// La clé anon/publishable est destinée au navigateur.
// NE JAMAIS mettre ici la clé service_role ou une clé secrète.
window.LK_SUPABASE_URL = "https://VOTRE-PROJET.supabase.co";
window.LK_SUPABASE_ANON_KEY = "VOTRE-CLE-ANON-PUBLIQUE";
