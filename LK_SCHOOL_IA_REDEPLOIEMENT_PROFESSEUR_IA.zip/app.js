import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = window.LK_SUPABASE_URL || "";
const SUPABASE_ANON_KEY = window.LK_SUPABASE_ANON_KEY || "";
const supabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY &&
  !SUPABASE_URL.includes("VOTRE-PROJET") && !SUPABASE_ANON_KEY.includes("VOTRE-CLE"));

const authForm = document.getElementById("auth-form");
const authName = document.getElementById("auth-name");
const authEmail = document.getElementById("auth-email");
const authPassword = document.getElementById("auth-password");
const authRole = document.getElementById("auth-role");
const authMessage = document.getElementById("auth-message");
const authSubmit = document.getElementById("auth-submit");
const userPanel = document.getElementById("user-panel");
const userSummary = document.getElementById("user-summary");
const signupTab = document.getElementById("show-signup");
const loginTab = document.getElementById("show-login");
let authMode = "signup";
let supabase = null;

function showAuthMessage(message, isError = false) {
  authMessage.textContent = message;
  authMessage.classList.toggle("error", isError);
}
function setMode(mode) {
  authMode = mode;
  const signup = mode === "signup";
  signupTab.classList.toggle("active", signup);
  loginTab.classList.toggle("active", !signup);
  authName.hidden = !signup;
  authName.previousElementSibling.hidden = !signup;
  authRole.hidden = !signup;
  authRole.previousElementSibling.hidden = !signup;
  authPassword.autocomplete = signup ? "new-password" : "current-password";
  authSubmit.textContent = signup ? "Créer mon compte" : "Me connecter";
}
signupTab.addEventListener("click", () => setMode("signup"));
loginTab.addEventListener("click", () => setMode("login"));

function requireSupabase() {
  if (!supabaseConfigured || !supabase) {
    showAuthMessage("La connexion n'est pas encore activée : le projet Supabase et ses deux paramètres publics doivent être configurés. Suis le guide README-CONNEXIONS-FR.txt. Ne colle jamais une clé secrète ou service_role dans le site.", true);
    return false;
  }
  return true;
}

async function refreshUser(session) {
  if (!session?.user) {
    userPanel.hidden = true;
    authForm.hidden = false;
    return;
  }
  authForm.hidden = true;
  userPanel.hidden = false;
  const { data: profile } = await supabase
    .from("profiles")
    .select("display_name, role, requested_role")
    .eq("id", session.user.id)
    .maybeSingle();
  const roleLabels = { student: "Élève / étudiant", teacher: "Enseignant", parent: "Parent", admin: "Administrateur" };
  const role = profile?.role || "student";
  const name = profile?.display_name || session.user.email || "Utilisateur";
  userSummary.textContent = `Connecté : ${name} — ${roleLabels[role] || role}`;
  if (profile?.requested_role && profile.requested_role !== role) {
    userSummary.textContent += ` · Demande d'accès ${roleLabels[profile.requested_role] || profile.requested_role} en attente de validation`;
  }
}

authForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!requireSupabase()) return;
  authSubmit.disabled = true;
  try {
    if (authMode === "signup") {
      const email = authEmail.value.trim();
      const requestedRole = authRole.value;
      const { data, error } = await supabase.auth.signUp({
        email,
        password: authPassword.value,
        options: {
          data: { display_name: authName.value.trim(), requested_role: requestedRole },
          emailRedirectTo: window.location.origin
        }
      });
      if (error) throw error;
      if (data.session) {
        showAuthMessage("Compte créé. Tu es connecté.");
        await refreshUser(data.session);
      } else {
        showAuthMessage("Inscription envoyée. Vérifie ta boîte e-mail pour confirmer ton adresse, puis connecte-toi.");
      }
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: authEmail.value.trim(),
        password: authPassword.value
      });
      if (error) throw error;
      showAuthMessage("Connexion réussie.");
      await refreshUser(data.session);
    }
  } catch (error) {
    showAuthMessage(error.message || "Une erreur est survenue pendant l'authentification.", true);
  } finally {
    authSubmit.disabled = false;
  }
});

async function oauth(provider) {
  if (!requireSupabase()) return;
  const { error } = await supabase.auth.signInWithOAuth({
    provider,
    options: { redirectTo: window.location.origin }
  });
  if (error) showAuthMessage(error.message, true);
}
document.getElementById("google-login").addEventListener("click", () => oauth("google"));
document.getElementById("apple-login").addEventListener("click", () => oauth("apple"));
document.getElementById("logout-btn").addEventListener("click", async () => {
  if (!requireSupabase()) return;
  const { error } = await supabase.auth.signOut();
  if (error) showAuthMessage(error.message, true);
  else {
    showAuthMessage("Tu es déconnecté.");
    await refreshUser(null);
  }
});

if (supabaseConfigured) {
  supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  supabase.auth.onAuthStateChange((_event, session) => {
    // Defer the profile read to avoid blocking Supabase's auth callback.
    setTimeout(() => refreshUser(session), 0);
  });
  supabase.auth.getSession().then(({ data }) => refreshUser(data.session));
} else {
  showAuthMessage("Formulaires de connexion intégrés, mais pas encore activés. Il faut créer/configurer le projet Supabase et ajouter l'URL du projet ainsi que la clé anon publique dans supabase-config.js. Consulte le guide fourni.");
}

// Existing AI teacher form
const form = document.getElementById("ask-form");
const question = document.getElementById("question");
const answer = document.getElementById("answer");
const button = document.getElementById("ask-btn");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const prompt = question.value.trim();
  if (!prompt) return;
  button.disabled = true;
  button.textContent = "Réflexion en cours…";
  answer.classList.add("loading");
  answer.textContent = "Ton professeur IA prépare une explication…";
  try {
    const response = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: prompt })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Erreur du serveur (${response.status}).`);
    answer.textContent = data.answer || "Aucune réponse reçue. Réessaie.";
  } catch (error) {
    answer.textContent = "Le professeur IA n'a pas pu répondre. " + error.message +
      " Vérifie le déploiement Cloudflare Pages et le secret OPENAI_API_KEY.";
  } finally {
    button.disabled = false;
    button.textContent = "Demander à l’IA ↗";
    answer.classList.remove("loading");
  }
});
