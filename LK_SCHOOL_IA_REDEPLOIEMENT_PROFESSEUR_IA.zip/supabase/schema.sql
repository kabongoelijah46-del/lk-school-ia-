-- L K SCHOOL IA : schéma initial Supabase
-- À exécuter dans Supabase > SQL Editor.
-- Les nouveaux comptes reçoivent le rôle student par défaut.
-- Les rôles teacher, parent et admin doivent être accordés par un administrateur.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'student'
    check (role in ('student','teacher','parent','admin')),
  requested_role text
    check (requested_role in ('student','teacher','parent')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.is_lk_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.protect_profile_role()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.role is distinct from old.role and coalesce(auth.role(), '') <> 'service_role' then
    raise exception 'Le rôle doit être modifié par un administrateur autorisé.';
  end if;
  return new;
end;
$$;

drop trigger if exists protect_profile_role on public.profiles;
create trigger protect_profile_role
before update on public.profiles
for each row execute function public.protect_profile_role();

create or replace function public.handle_new_lk_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  wanted_role text;
begin
  wanted_role := coalesce(new.raw_user_meta_data->>'requested_role', 'student');
  if wanted_role not in ('student','teacher','parent') then
    wanted_role := 'student';
  end if;
  insert into public.profiles (id, display_name, role, requested_role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', ''),
    'student',
    wanted_role
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_lk_auth_user_created on auth.users;
create trigger on_lk_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_lk_user();

alter table public.profiles enable row level security;

drop policy if exists "Read own profile or admin" on public.profiles;
create policy "Read own profile or admin"
on public.profiles for select
to authenticated
using (id = auth.uid() or public.is_lk_admin());

drop policy if exists "Update own basic profile or admin" on public.profiles;
create policy "Update own basic profile or admin"
on public.profiles for update
to authenticated
using (id = auth.uid() or public.is_lk_admin())
with check (id = auth.uid() or public.is_lk_admin());

-- Les utilisateurs ne peuvent pas s'attribuer eux-mêmes les rôles privilégiés.
-- Pour promouvoir un enseignant/parent ou créer un administrateur, exécuter
-- une commande SQL contrôlée depuis le tableau de bord Supabase (exemples ci-dessous).

-- Après inscription du compte principal, remplacer l'adresse ci-dessous :
-- update public.profiles p set role='admin', requested_role=null
-- from auth.users u where p.id=u.id and lower(u.email)=lower('TON-EMAIL@EXEMPLE.COM');

-- Après inscription du compte de la grande sœur, remplacer son adresse :
-- update public.profiles p set role='admin', requested_role=null
-- from auth.users u where p.id=u.id and lower(u.email)=lower('EMAIL-SOEUR@EXEMPLE.COM');

-- Pour approuver un enseignant ou parent :
-- update public.profiles p set role=p.requested_role, requested_role=null
-- where p.id='UUID_DU_COMPTE' and p.requested_role in ('teacher','parent');
