export async function onRequestPost({ request, env }) {
  if (!env.OPENAI_API_KEY) {
    return Response.json(
      { error: "Le secret OPENAI_API_KEY est absent des paramètres Cloudflare." },
      { status: 503 }
    );
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Le corps de la requête doit être au format JSON." }, { status: 400 });
  }

  const question = typeof body.question === "string" ? body.question.trim() : "";
  if (!question) {
    return Response.json({ error: "Écris d'abord ta question." }, { status: 400 });
  }
  if (question.length > 5000) {
    return Response.json({ error: "La question dépasse la limite de 5 000 caractères." }, { status: 400 });
  }

  const model = env.OPENAI_MODEL || "gpt-4.1-mini";
  let upstream;
  try {
    upstream = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        messages: [
          {
            role: "system",
            content: "Tu es le professeur pédagogique de L K SCHOOL IA. Aide les élèves, enseignants et parents en français simple, avec un ton encourageant et adapté à l'âge. Explique étape par étape, définis les mots difficiles et donne des exemples concrets. Pour les quiz, pose une question à la fois, attends la réponse de l'élève, puis corrige et explique. Ne prétends jamais avoir consulté Internet, des documents ou des sources que tu n'as pas réellement reçus. Si une question est ambiguë, demande une précision."
          },
          { role: "user", content: question }
        ],
        temperature: 0.5,
        max_tokens: 1000
      })
    });
  } catch {
    return Response.json({ error: "Impossible de joindre le service OpenAI depuis Cloudflare." }, { status: 502 });
  }

  const result = await upstream.json().catch(() => ({}));
  if (!upstream.ok) {
    const status = upstream.status === 429 ? 429 : 502;
    let message = result?.error?.message || "Le fournisseur IA a refusé la requête.";
    if (upstream.status === 401) message = "OpenAI a refusé la clé API. Vérifie le secret OPENAI_API_KEY dans Cloudflare.";
    if (upstream.status === 429) message = "Limite ou crédit API OpenAI atteint. Vérifie la facturation et les limites de ton compte API.";
    return Response.json({ error: message }, { status });
  }

  const text = result?.choices?.[0]?.message?.content?.trim();
  if (!text) {
    return Response.json({ error: "OpenAI n'a pas renvoyé de réponse exploitable." }, { status: 502 });
  }
  return Response.json({ answer: text });
}
